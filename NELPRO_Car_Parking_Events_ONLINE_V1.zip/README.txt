NELPRO CAR PARKING EVENTS — V1 ONLINE

Esta versão já tem backend e base de dados:
- Login por e-mail + nome
- Sessão por token
- Qualquer utilizador autenticado pode publicar eventos
- Todos os utilizadores consultam os mesmos eventos
- SQLite para guardar utilizadores e eventos

COMO EXECUTAR NO COMPUTADOR:
1. Instale Node.js 20+.
2. Abra um terminal nesta pasta.
3. Entre na pasta server: npm install
4. Execute: npm start
5. Abra http://localhost:3000

PARA FICAR ONLINE PARA TODOS:
É necessário colocar este projeto num serviço de hospedagem que execute Node.js e tenha armazenamento persistente para a base SQLite. Depois, todos entram pelo endereço público.

IMPORTANTE:
O app não usa nem pede a senha da conta do Car Parking. O e-mail digitado é apenas usado como identificador do perfil. Para autenticação oficial com uma conta externa, seria necessário suporte/API oficial do serviço correspondente.
