
const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const db = new Database("nelpro.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  place TEXT,
  cars TEXT,
  description TEXT,
  author_id INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(author_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

function auth(req,res,next){
  const token = req.headers.authorization?.replace("Bearer ","");
  if(!token) return res.status(401).json({error:"Login necessário"});
  const row = db.prepare(`
    SELECT users.* FROM sessions JOIN users ON users.id=sessions.user_id
    WHERE sessions.token=?
  `).get(token);
  if(!row) return res.status(401).json({error:"Sessão inválida"});
  req.user=row; next();
}

app.post("/api/login",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase();
  const name=String(req.body.name||"").trim();
  if(!email || !name) return res.status(400).json({error:"E-mail e nome são obrigatórios"});
  let u=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!u){
    const r=db.prepare("INSERT INTO users(email,name) VALUES(?,?)").run(email,name);
    u=db.prepare("SELECT * FROM users WHERE id=?").get(r.lastInsertRowid);
  } else {
    db.prepare("UPDATE users SET name=? WHERE id=?").run(name,u.id);
    u={...u,name};
  }
  const token=crypto.randomBytes(32).toString("hex");
  db.prepare("INSERT INTO sessions(token,user_id) VALUES(?,?)").run(token,u.id);
  res.json({token,user:{id:u.id,email:u.email,name:u.name}});
});

app.get("/api/events",(req,res)=>{
  const rows=db.prepare(`
    SELECT events.*, users.name AS author
    FROM events JOIN users ON users.id=events.author_id
    ORDER BY events.created_at DESC
  `).all();
  res.json(rows);
});

app.post("/api/events",auth,(req,res)=>{
  const {title,date,time,place="",cars="",description=""}=req.body;
  if(!title || !date || !time) return res.status(400).json({error:"Nome, data e hora são obrigatórios"});
  const r=db.prepare(`
    INSERT INTO events(title,date,time,place,cars,description,author_id)
    VALUES(?,?,?,?,?,?,?)
  `).run(title,date,time,place,cars,description,req.user.id);
  res.json(db.prepare(`
    SELECT events.*, users.name AS author FROM events
    JOIN users ON users.id=events.author_id WHERE events.id=?
  `).get(r.lastInsertRowid));
});

app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../public/index.html")));

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`NELPRO online em http://localhost:${PORT}`));
